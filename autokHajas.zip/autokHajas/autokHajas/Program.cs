﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace autokHajas
{
    internal class Auto
    {
        public string Rendszam { get; set; }
        public string Tipus { get; set; }
        public string Szin { get; set; }
        public int Evjarat { get; set; }
        public int Ar { get; set; }
        public string Hasznalo { get; set; }

        public Auto(string rendszam, string tipus, string szin, int evjarat, int ar, string hasznalo)
        {
            Rendszam = rendszam;
            Tipus = tipus;
            Szin = szin;
            Evjarat = evjarat;
            Ar = ar;
            Hasznalo = hasznalo;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            List<Auto> autok = new List<Auto>();

            try
            {
                
                string[] sorok = File.ReadAllLines("autok.txt");
                foreach (string sor in sorok)
                {
                    string[] adat = sor.Split('\t');
                    string rendszam = adat[0];
                    string tipus = adat[1];
                    string szin = adat[2];
                    int evjarat = Convert.ToInt32(adat[3]);
                    string arSzoveg = adat[4].Replace(" ", "").Replace(",", "");
                    int ar = Convert.ToInt32(arSzoveg);
                    string hasznalo = adat[5];

                    Auto egyAuto = new Auto(rendszam, tipus, szin, evjarat, ar, hasznalo);
                    autok.Add(egyAuto);
                }

               
                Console.WriteLine("Összesen " + autok.Count + " autó szerepel a listában.");

                
                Dictionary<string, (int darab, long ertek)> stat = new Dictionary<string, (int, long)>();

                foreach (Auto a in autok)
                {
                    bool talalat = false;

                    foreach (string kulcs in stat.Keys.ToList()) // ToList miatt biztonságos a módosítás
                    {
                        if (kulcs == a.Tipus)
                        {
                            var adat = stat[kulcs];
                            stat[kulcs] = (adat.darab + 1, adat.ertek + a.Ar);
                            talalat = true;
                        }
                    }

                    if (!talalat)
                    {
                        stat[a.Tipus] = (1, a.Ar);
                    }
                }

                Console.WriteLine("Autók típusok szerint:");
                foreach (var par in stat)
                {
                    Console.WriteLine(par.Key + " -> " + par.Value.darab + " darab, összes érték: " + par.Value.ertek + " Ft");
                }

                
                Auto legdragabb = autok[0];
                foreach (Auto a in autok)
                {
                    if (a.Ar > legdragabb.Ar)
                    {
                        legdragabb = a;
                    }
                }

                Console.WriteLine("A legdrágább autó adatai:");
                Console.WriteLine("Rendszám: " + legdragabb.Rendszam);
                Console.WriteLine("Típus: " + legdragabb.Tipus);
                Console.WriteLine("Szín: " + legdragabb.Szin);
                Console.WriteLine("Évjárat: " + legdragabb.Evjarat);
                Console.WriteLine("Érték: " + legdragabb.Ar + " Ft");
                Console.WriteLine("Használó: " + legdragabb.Hasznalo);

               
                StreamWriter iro = new StreamWriter("autok_kiiras.txt");
                foreach (Auto a in autok)
                {
                    iro.WriteLine(a.Tipus + ";" + a.Szin + ";" + a.Hasznalo);
                }
                iro.Close();
                Console.WriteLine("Az adatok mentése elkészült az autok_kiiras.txt fájlba.");
            }
            catch (Exception hiba)
            {
                Console.WriteLine("Hiba történt: " + hiba.Message);
            }

            Console.ReadKey();
        }
    }
}
