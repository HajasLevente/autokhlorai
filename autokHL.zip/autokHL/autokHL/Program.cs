﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace autokHL
{
    internal class Program
    {
        struct Auto
        {
            public string Rendszam;
            public string Tipus;
            public string Szin;
            public int Evjarat;
            public int Ar;
            public string Hasznalo;
        }

        static void Main(string[] args)
        {
            List<Auto> autok = new List<Auto>();

            try
            {
                foreach (var sor in File.ReadAllLines("autok.txt"))
                {
                    string[] seged = sor.Split('\t');
                    string arSzoveg = seged[4]
                        .Replace(" ", "")
                        .Replace(".", "")
                        .Split(',')[0];

                    Auto egyAuto = new Auto
                    {
                        Rendszam = seged[0],
                        Tipus = seged[1],
                        Szin = seged[2],
                        Evjarat = Convert.ToInt32(seged[3]),
                        Ar = Convert.ToInt32(arSzoveg),
                        Hasznalo = seged[5]
                    };
                    autok.Add(egyAuto);
                }

                Console.WriteLine($"Az állományban {autok.Count} autó szerepel.");

                var tipusStatisztika = autok
                    .GroupBy(a => a.Tipus)
                    .Select(g => new
                    {
                        Tipus = g.Key,
                        Db = g.Count(),
                        Osszertek = g.Sum(a => a.Ar)
                    });

                Console.WriteLine("\nAutók típusonkénti megoszlása és összértéke:");
                foreach (var t in tipusStatisztika)
                {
                    Console.WriteLine($"- {t.Tipus}: {t.Db} darab, összesen {t.Osszertek:N0} Ft értékben");
                }

                Auto legdragabb = autok.OrderByDescending(a => a.Ar).First();
                Console.WriteLine("\nA legdrágább autó adatai:");
                Console.WriteLine($"Rendszám: {legdragabb.Rendszam}");
                Console.WriteLine($"Márka és típus: {legdragabb.Tipus}");
                Console.WriteLine($"Szín: {legdragabb.Szin}");
                Console.WriteLine($"Évjárat: {legdragabb.Evjarat}");
                Console.WriteLine($"Érték: {legdragabb.Ar:N0} Ft");
                Console.WriteLine($"Használó: {legdragabb.Hasznalo}");

                using (StreamWriter sw = new StreamWriter("autok_kivonat.txt"))
                {
                    foreach (var auto in autok)
                    {
                        sw.WriteLine($"{auto.Tipus};{auto.Szin};{auto.Hasznalo}");
                    }
                }

                Console.WriteLine("\nAz autók kivonata elkészült: autok_kivonat.txt");
            }
            catch (Exception hiba)
            {
                Console.WriteLine($"Hiba történt a feldolgozás során: {hiba.Message}");
            }

            Console.ReadKey();
        }
    }
}
